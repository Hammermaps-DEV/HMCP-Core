<?php
/**
 *
 * This file is part of phpFastCache.
 *
 * @license MIT License (MIT)
 *
 * For full copyright and license information, please see the docs/CREDITS.txt file.
 *
 * @author Khoa Bui (khoaofgod)  <khoaofgod@gmail.com> http://www.phpfastcache.com
 * @author Georges.L (Geolim4)  <contact@geolim4.com>
 *
 */

namespace phpFastCache\Drivers;

use phpFastCache\Core\DriverAbstract;
use phpFastCache\Exceptions\phpFastCacheDriverException;

/**
 * Class zend_shm (zend memory cache)
 * Requires Zend Data Cache Functions from ZendServer
 * @package phpFastCache\Drivers
 */
class zend_shm extends DriverAbstract
{
    /**
     * phpFastCache_zend_shm constructor.
     * @param array $config
     * @throws phpFastCacheDriverException
     */
    public function __construct($config = array())
    {
        $this->setup($config);

        if (!$this->checkdriver()) {
            throw new phpFastCacheDriverException('Zend Memory Cache is not installed, cannot continue.');
        }
    }

    /**
     * @return bool
     */
    public function checkdriver()
    {
        if (extension_loaded('Zend Data Cache') && function_exists('zend_shm_cache_store')) {
            return true;
        } else {
            $this->fallback = true;
            return false;
        }
    }

    /**
     * @param $keyword
     * @param string $value
     * @param int $time
     * @param array $option
     * @return array|bool
     */
    public function driver_set(
      $keyword,
      $value = '',
      $time = 300,
      $option = array()
    ) {
        if (isset($option[ 'skipExisting' ]) && $option[ 'skipExisting' ] == true) {
            return zend_shm_cache_add($keyword, $value, $time);
        } else {
            return zend_shm_cache_store($keyword, $value, $time);
        }
    }

    /**
     * @param $keyword
     * @param array $option
     * @return mixed|null
     */
    public function driver_get($keyword, $option = array())
    {
        $data = zend_shm_cache_fetch($keyword);
        if ($data === false) {
            return null;
        }
        return $data;
    }

    /**
     * @param $keyword
     * @param array $option
     * @return bool|\string[]
     */
    public function driver_delete($keyword, $option = array())
    {
        return zend_shm_cache_delete($keyword);
    }

    /**
     * @param array $option
     * @return array
     */
    public function driver_stats($option = array())
    {
        $res = array(
            'info' => '',
            'size' => '',
            'data' => '',
        );

        try {
            $res[ 'data' ] = zend_shm_cache_info();
        } catch (\Exception $e) {
            $res[ 'data' ] = array();
        }

        return $res;
    }

    /**
     * @param array $option
     * @return void
     */
    public function driver_clean($option = array())
    {
        @zend_shm_cache_clear();
    }

    /**
     * @param $keyword
     * @return bool
     */
    public function driver_isExisting($keyword)
    {
        return (zend_shm_cache_fetch($keyword) === false ? false : true);
    }
}